package astral;

import astral.drop.Drop;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.Vec3;

/**
 * Le bloc Astral Lucky Block. La luck (-2..+2, stockee de 0 a 4) et l'eventuel "variant" (drop sur mesure
 * des structures) sont portes par l'etat du bloc : pas besoin de BlockEntity.
 */
public class AstralLuckyBlock extends Block {
    public static final IntegerProperty LUCK = IntegerProperty.create("luck", 0, 4);
    public static final IntegerProperty VARIANT = IntegerProperty.create("variant", 0, 7);

    public AstralLuckyBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(LUCK, 2).setValue(VARIANT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LUCK, VARIANT);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
            if (!(player.isCreative() && !Config.dropsInCreative)) {
                int luck = state.getValue(LUCK) - 2;
                Drop drop = state.getValue(VARIANT) > 0
                    ? DropRegistry.variant(state.getValue(VARIANT))
                    : DropRegistry.pick(DropRegistry.Kind.BLOCK, luck);
                var env = DropRunner.env(sl, sp, new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5));
                // 1 tick de delai : le bloc doit avoir disparu avant que les actions (fill, setblock...) ne s'executent
                Scheduler.schedule(1, () -> DropRunner.run(drop, env));
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }
}
