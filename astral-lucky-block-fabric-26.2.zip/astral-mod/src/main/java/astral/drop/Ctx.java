package astral.drop;

import java.util.Random;
import java.util.function.Supplier;

/** Contexte d'evaluation des fonctions #xxx. Independant de Minecraft pour pouvoir etre teste. */
public final class Ctx {
    public final Random rnd = new Random();
    public String playerName = "Player";
    public double px, py, pz;          // position exacte du joueur
    public double yaw, pitch;          // orientation du joueur
    public double dx, dy, dz;          // direction du regard (unitaire)
    public int bx, by, bz;             // position du bloc / de l'impact
    public Supplier<String> spawnEgg = () -> "pig_spawn_egg";   // remplace par le mod : oeuf aleatoire
    public double bowX, bowY, bowZ, bowMx, bowMy, bowMz;
}
