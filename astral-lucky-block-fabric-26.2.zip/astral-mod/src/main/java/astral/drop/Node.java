package astral.drop;

import java.util.*;

/** Noeud d'un drop : soit un groupe d'actions, soit une action (type=...). Sans dependance Minecraft. */
public final class Node {
    public final List<Node> children;          // non null => groupe
    public final String pick;                  // groupe "group:N:(...)" : tire N enfants (N peut etre #rand) ; null = tous
    public final Map<String, String> attrs;    // non null => action
    public Node(List<Node> children, String pick) { this.children = children; this.pick = pick; this.attrs = null; }
    public Node(Map<String, String> attrs) { this.children = null; this.pick = null; this.attrs = attrs; }
    public boolean isGroup() { return children != null; }
}
