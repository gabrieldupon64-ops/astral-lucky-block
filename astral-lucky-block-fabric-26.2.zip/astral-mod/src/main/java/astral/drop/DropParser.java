package astral.drop;

import java.util.*;
import java.util.regex.*;

/** Parseur du format de drops Lucky Block ("group(type=...;type=...)@luck=2@chance=0.5"). */
public final class DropParser {
    private static final Pattern SUFFIX = Pattern.compile("((?:@[a-zA-Z]+=-?[0-9.]+)+)\\s*$");

    public static List<Drop> parse(String text) {
        text = text.replace("\r", "").replaceAll("\\\\\\n", "");
        List<Drop> out = new ArrayList<>();
        for (String raw : text.split("\n")) {
            String line = raw.strip();
            if (line.isEmpty() || line.startsWith("/") || line.startsWith(">")) continue;
            try { Drop d = parseLine(line); if (d != null) out.add(d); }
            catch (RuntimeException e) { System.err.println("[astral] drop ignore (" + e.getMessage() + "): " + line.substring(0, Math.min(80, line.length()))); }
        }
        return out;
    }

    public static Drop parseLine(String line) {
        double chance = 1; int luck = 0;
        Matcher m = SUFFIX.matcher(line);
        if (m.find()) {
            for (String s : m.group(1).split("@")) {
                if (s.startsWith("luck=")) luck = (int) Double.parseDouble(s.substring(5));
                else if (s.startsWith("chance=")) chance = Double.parseDouble(s.substring(7));
            }
            line = line.substring(0, m.start()).strip();
        }
        return new Drop(parseNode(line), chance, luck, line);
    }

    static Node parseNode(String s) {
        s = s.strip();
        if (s.startsWith("group")) {
            int i = 5; String pick = null;
            if (s.charAt(i) == ':') { int j = i + 1, d = 0; while (j < s.length() && !(s.charAt(j) == ':' && d == 0)) { if (s.charAt(j) == '(') d++; if (s.charAt(j) == ')') d--; j++; } pick = s.substring(i + 1, j); i = j + 1; }
            if (s.charAt(i) != '(') throw new IllegalArgumentException("group sans parenthese");
            int end = matching(s, i);
            List<Node> kids = new ArrayList<>();
            for (String part : split(s.substring(i + 1, end), ';')) if (!part.isBlank()) kids.add(parseNode(part));
            return new Node(kids, pick);
        }
        Map<String, String> attrs = new LinkedHashMap<>();
        boolean implicitItem = !s.startsWith("type=");
        for (String kv : split(s, ',')) {
            int eq = kv.indexOf('=');
            if (eq < 0) continue;
            String v = kv.substring(eq + 1).strip();
            if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
            attrs.putIfAbsent(kv.substring(0, eq).strip(), v);
        }
        if (!attrs.containsKey("type")) {
            if (!implicitItem || !attrs.containsKey("ID")) throw new IllegalArgumentException("type manquant");
            attrs.put("type", "item");     // "ID=diamond,amount=3" = objet pose au sol
        }
        return new Node(attrs);
    }

    /** Index de la parenthese fermante correspondant a celle en position open. */
    static int matching(String s, int open) {
        int depth = 0; boolean q = false;
        for (int i = open; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
            if (q) continue;
            if (c == '(') depth++;
            else if (c == ')' && --depth == 0) return i;
        }
        throw new IllegalArgumentException("parenthese non fermee");
    }

    /** Decoupe sur sep au niveau 0 (hors guillemets, parentheses, crochets, accolades). */
    static List<String> split(String s, char sep) {
        List<String> out = new ArrayList<>();
        int depth = 0, start = 0; boolean q = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
            if (q) continue;
            if (c == '(' || c == '[' || c == '{') depth++;
            else if (c == ')' || c == ']' || c == '}') depth--;
            else if (c == sep && depth == 0) { out.add(s.substring(start, i)); start = i + 1; }
        }
        out.add(s.substring(start));
        return out;
    }
}
