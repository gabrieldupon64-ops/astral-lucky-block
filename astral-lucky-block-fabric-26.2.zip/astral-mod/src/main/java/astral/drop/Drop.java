package astral.drop;

/** Un drop complet : arbre d'actions + ponderation (@chance) + luck (@luck, -2..2). */
public record Drop(Node root, double chance, int luck, String source) {
    /** Poids selon la luck du bloc (-2..2). luckLevel>0 favorise les drops positifs, <0 les negatifs. */
    public double weight(int blockLuck) {
        double f = 1.0 + (blockLuck * luck) * 0.35;
        return chance * Math.max(0.05, f);
    }
}
