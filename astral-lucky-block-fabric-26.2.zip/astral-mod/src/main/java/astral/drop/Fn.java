package astral.drop;

import java.util.*;
import java.util.regex.*;

/** Resolution des fonctions #rand, #randList, #circleOffset, #pName, etc. dans une chaine. */
public final class Fn {
    private static final String NAMES = "randList|rand|circleOffset|motionFromDirection|randLaunchMotion|randSpawnEgg|pExactPos|pDirect|pName|pPos|pYaw|pPitch|bPosX|bPosY|bPosZ|bPos|bowPos|bowMotion|rel";
    private static final Pattern TOKEN = Pattern.compile("#(" + NAMES + ")(?![A-Za-z])");
    private static final Pattern NUM = Pattern.compile("-?\\d+(?:\\.\\d+)?");

    public static String resolve(String s, Ctx c) {
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < s.length()) {
            Matcher m = TOKEN.matcher(s);
            if (!m.find(i)) { out.append(s, i, s.length()); break; }
            out.append(s, i, m.start());
            String name = m.group(1);
            int end = m.end();
            List<String> args = List.of();
            if (end < s.length() && s.charAt(end) == '(' && hasArgs(name)) {
                int close = DropParser.matching(s, end);
                args = DropParser.split(s.substring(end + 1, close), ',');
                end = close + 1;
            }
            String val = eval(name, args, c);
            // arithmetique : #bPosY+7, #pYaw+#rand(-10,10)
            if (isNumeric(name)) {
                double v = Double.parseDouble(val);
                while (end < s.length() && (s.charAt(end) == '+' || s.charAt(end) == '-')) {
                    char op = s.charAt(end);
                    int k = end + 1;
                    String rhs;
                    Matcher t = TOKEN.matcher(s);
                    if (t.find(k) && t.start() == k) {
                        int e2 = t.end(); List<String> a2 = List.of();
                        if (e2 < s.length() && s.charAt(e2) == '(' && hasArgs(t.group(1))) { int cl = DropParser.matching(s, e2); a2 = DropParser.split(s.substring(e2 + 1, cl), ','); e2 = cl + 1; }
                        rhs = eval(t.group(1), a2, c); k = e2;
                    } else {
                        Matcher n = NUM.matcher(s); if (!n.find(k) || n.start() != k) break;
                        rhs = n.group(); k = n.end();
                    }
                    v = op == '+' ? v + Double.parseDouble(rhs) : v - Double.parseDouble(rhs);
                    end = k;
                }
                val = fmt(v, val.contains(".") || name.equals("pYaw") || name.equals("pPitch"));
            }
            out.append(val);
            i = end;
        }
        return out.toString();
    }

    static boolean hasArgs(String n) { return n.equals("rand") || n.equals("randList") || n.equals("circleOffset") || n.equals("motionFromDirection") || n.equals("rel"); }
    static boolean isNumeric(String n) { return n.equals("rand") || n.equals("pYaw") || n.equals("pPitch") || n.equals("bPosX") || n.equals("bPosY") || n.equals("bPosZ"); }
    static String fmt(double v, boolean dec) { return dec ? String.format(Locale.ROOT, "%.3f", v) : Long.toString(Math.round(v)); }

    private static String eval(String name, List<String> a, Ctx c) {
        switch (name) {
            case "rand": {
                String lo = resolve(a.get(0).strip(), c), hi = resolve(a.get(1).strip(), c);
                boolean dec = lo.contains(".") || hi.contains(".");
                double l = Double.parseDouble(lo), h = Double.parseDouble(hi);
                double v = l + c.rnd.nextDouble() * (h - l);
                return dec ? String.format(Locale.ROOT, "%.3f", v) : Long.toString(Math.round(Math.floor(l + c.rnd.nextDouble() * (h - l + 1))));
            }
            case "randList": return resolve(a.get(c.rnd.nextInt(a.size())).strip(), c);
            case "circleOffset": {
                double in = a.size() > 1 ? Double.parseDouble(resolve(a.get(0).strip(), c)) : 0;
                double outR = Double.parseDouble(resolve(a.get(a.size() - 1).strip(), c));
                double r = in + c.rnd.nextDouble() * (outR - in), t = c.rnd.nextDouble() * Math.PI * 2;
                return String.format(Locale.ROOT, "(%.3f,0,%.3f)", Math.cos(t) * r, Math.sin(t) * r);
            }
            case "pName": return c.playerName;
            case "pPos": return Math.round(Math.floor(c.px)) + " " + Math.round(Math.floor(c.py)) + " " + Math.round(Math.floor(c.pz));
            case "pExactPos": return String.format(Locale.ROOT, "%.3f %.3f %.3f", c.px, c.py, c.pz);
            case "pDirect": return String.format(Locale.ROOT, "%.3f %.3f %.3f", c.px + c.dx * 2, c.py + 1 + c.dy * 2, c.pz + c.dz * 2);
            case "pYaw": return String.format(Locale.ROOT, "%.3f", c.yaw);
            case "pPitch": return String.format(Locale.ROOT, "%.3f", c.pitch);
            case "bPosX": return Integer.toString(c.bx);
            case "bPosY": return Integer.toString(c.by);
            case "bPosZ": return Integer.toString(c.bz);
            case "bPos": return c.bx + " " + c.by + " " + c.bz;
            case "bowPos": return String.format(Locale.ROOT, "%.3f %.3f %.3f", c.bowX, c.bowY, c.bowZ);
            case "bowMotion": return String.format(Locale.ROOT, "[%.4fd,%.4fd,%.4fd]", c.bowMx, c.bowMy, c.bowMz);
            case "motionFromDirection": {
                double yaw = Math.toRadians(Double.parseDouble(resolve(a.get(0).strip(), c)));
                double pit = Math.toRadians(Double.parseDouble(resolve(a.get(1).strip(), c)));
                double sp = Double.parseDouble(resolve(a.get(2).strip(), c));
                return String.format(Locale.ROOT, "[%.4fd,%.4fd,%.4fd]", -Math.sin(yaw) * Math.cos(pit) * sp, -Math.sin(pit) * sp, Math.cos(yaw) * Math.cos(pit) * sp);
            }
            case "randLaunchMotion": {
                double t = c.rnd.nextDouble() * Math.PI * 2, s = 0.1 + c.rnd.nextDouble() * 0.3;
                return String.format(Locale.ROOT, "[%.4fd,%.4fd,%.4fd]", Math.cos(t) * s, 0.2 + c.rnd.nextDouble() * 0.4, Math.sin(t) * s);
            }
            case "rel": {
                int rx = Integer.parseInt(a.get(0).strip()), ry = Integer.parseInt(a.get(1).strip()), rz = Integer.parseInt(a.get(2).strip());
                return (c.bx + rx) + " " + (c.by + ry) + " " + (c.bz + rz);
            }
            case "randSpawnEgg": return c.spawnEgg.get();
            default: return "#" + name;
        }
    }
}
