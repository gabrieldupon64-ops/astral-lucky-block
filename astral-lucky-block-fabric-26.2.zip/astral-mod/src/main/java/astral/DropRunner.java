package astral;

import astral.drop.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Execute un drop Lucky Block : traduit chaque action (type=effect, particle, block, ...) en commandes
 * vanilla ou en appels Java. Les "delay=" passent par {@link Scheduler}.
 */
public final class DropRunner {
    /** Etat d'une execution de drop. */
    public static final class Env {
        public ServerLevel level;
        public Ctx ctx = new Ctx();
        public Vec3 origin;                 // position par defaut des actions
        public UUID hitEntity;              // pour target=hitEntity
        public String playerTarget;         // selecteur du joueur (nom)
    }

    public static Env env(ServerLevel level, ServerPlayer player, Vec3 origin) {
        Env e = new Env();
        e.level = level; e.origin = origin;
        Ctx c = e.ctx;
        c.spawnEgg = DropRunner::randomSpawnEgg;
        c.bx = BlockPos.containing(origin).getX(); c.by = BlockPos.containing(origin).getY(); c.bz = BlockPos.containing(origin).getZ();
        if (player != null) {
            c.playerName = player.getName().getString();
            c.px = player.getX(); c.py = player.getY(); c.pz = player.getZ();
            c.yaw = player.getYRot(); c.pitch = player.getXRot();
            Vec3 look = player.getLookAngle();
            c.dx = look.x; c.dy = look.y; c.dz = look.z;
            e.playerTarget = c.playerName;
        } else { c.px = origin.x; c.py = origin.y; c.pz = origin.z; }
        return e;
    }

    public static void run(Drop drop, Env env) {
        if (drop == null) return;
        runNode(drop.root(), env, 0);
    }

    private static void runNode(Node n, Env env, int baseDelay) {
        if (n.isGroup()) {
            List<Node> kids = new ArrayList<>(n.children);
            if (n.pick != null) {
                int k = (int) Math.round(Double.parseDouble(Fn.resolve(n.pick, env.ctx)));
                Collections.shuffle(kids, env.ctx.rnd);
                kids = kids.subList(0, Math.max(0, Math.min(k, kids.size())));
            }
            for (Node k : kids) runNode(k, env, baseDelay);
            return;
        }
        String type = n.attrs.get("type");
        int reps = 1;
        if (!type.equals("item") && n.attrs.containsKey("amount")) reps = Math.max(1, (int) Math.round(num(Fn.resolve(n.attrs.get("amount"), env.ctx), 1)));
        for (int i = 0; i < reps; i++) {
            Map<String, String> a = new HashMap<>();
            for (var e : n.attrs.entrySet()) a.put(e.getKey(), Fn.resolve(e.getValue(), env.ctx));
            Vec3 pos = position(a, env);
            int delay = baseDelay + (int) Math.round(num(a.get("delay"), 0) * 20);
            Scheduler.schedule(delay, () -> exec(type, a, pos, env));
        }
    }

    private static Vec3 position(Map<String, String> a, Env env) {
        Vec3 p = env.origin;
        if (a.containsKey("pos")) p = vec(a.get("pos"), p);
        if (a.containsKey("posOffset")) p = p.add(vec(a.get("posOffset"), Vec3.ZERO));
        p = p.add(num(a.get("posOffsetX"), 0), num(a.get("posOffsetY"), 0), num(a.get("posOffsetZ"), 0));
        if (a.containsKey("posY")) p = new Vec3(p.x, num(a.get("posY"), p.y), p.z);
        return p;
    }

    private static void exec(String type, Map<String, String> a, Vec3 pos, Env env) {
        ServerLevel level = env.level;
        MinecraftServer server = level.getServer();
        String id = a.getOrDefault("ID", "");
        try {
            switch (type) {
                case "nothing" -> {}
                case "command" -> cmd(env, pos, id.startsWith("/") ? id.substring(1) : id);
                case "item" -> {
                    String item = itemId(id);
                    if (item == null) return;
                    int count = Math.max(1, (int) Math.round(num(a.get("amount"), 1)));
                    while (count > 0) {
                        int c = Math.min(count, 64); count -= c;
                        cmd(env, pos, "summon item " + xyz(pos) + " {Item:{id:\"" + item + "\",count:" + c + "}}");
                    }
                }
                case "block" -> { String b = blockId(id); if (b != null) cmd(env, pos, "setblock " + bxyz(pos) + " " + b); }
                case "fill" -> {
                    String b = blockId(id); if (b == null) return;
                    Vec3 s = vec(a.getOrDefault("size", "(1,1,1)"), new Vec3(1, 1, 1));
                    int sx = (int) s.x, sy = (int) s.y, sz = (int) s.z;
                    BlockPos p = BlockPos.containing(pos).offset(-(sx / 2), 0, -(sz / 2));
                    cmd(env, pos, "fill " + p.getX() + " " + p.getY() + " " + p.getZ() + " " + (p.getX() + sx - 1) + " " + (p.getY() + sy - 1) + " " + (p.getZ() + sz - 1) + " " + b);
                }
                case "effect" -> effect(a, pos, env);
                case "particle" -> {
                    Vec3 s = vec(a.getOrDefault("size", "(0.5,0.5,0.5)"), new Vec3(0.5, 0.5, 0.5));
                    int n = (int) Math.round(num(a.get("particleAmount"), 10));
                    cmd(env, pos, "particle " + particleId(id) + " " + xyz(pos) + " " + f(s.x) + " " + f(s.y) + " " + f(s.z) + " 0.05 " + Math.min(n, 1000) + " force");
                }
                case "sound" -> cmd(env, pos, "playsound " + (id.contains(":") ? id : "minecraft:" + id) + " master @a " + xyz(pos) + " 1 " + f(num(a.get("pitch"), 1)));
                case "entity" -> cmd(env, pos, "summon " + entityId(id) + " " + xyz(pos));
                case "explosion" -> level.explode(null, pos.x, pos.y, pos.z, (float) num(a.get("damage"), 3), "true".equals(a.get("fire")), Level.ExplosionInteraction.TNT);
                case "difficulty" -> cmd(env, pos, "difficulty " + id);
                case "time" -> cmd(env, pos, "time set " + id);
                case "message" -> cmd(env, pos, "tellraw @a {\"text\":\"" + id.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}");
                case "structure" -> {
                    int rot = a.containsKey("rotation") ? (int) num(a.get("rotation"), 0) : env.ctx.rnd.nextInt(4);
                    StructurePlacer.place(level, id, BlockPos.containing(pos), rot);
                }
                default -> AstralMod.LOGGER.debug("type de drop non gere : {}", type);
            }
        } catch (RuntimeException e) {
            AstralMod.LOGGER.warn("action de drop '{}' en erreur : {}", type, e.toString());
        }
    }

    private static void effect(Map<String, String> a, Vec3 pos, Env env) {
        String id = a.getOrDefault("ID", "");
        double range = num(a.get("range"), 0);
        if (id.equals("special_knockback")) {          // effet "maison" de l'addon
            double power = num(a.get("power"), 1.5);
            double r = range > 0 ? range : 5;
            for (LivingEntity e : env.level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(r))) {
                if ("true".equals(a.get("excludePlayer")) && e instanceof ServerPlayer) continue;
                Vec3 d = e.position().subtract(pos);
                Vec3 push = new Vec3(d.x, 0, d.z).normalize().scale(power).add(0, 0.5, 0);
                e.push(push.x, push.y, push.z);
                e.hurtMarked = true;
            }
            return;
        }
        if (id.startsWith("special_")) return;
        String sel;
        if ("hitEntity".equals(a.get("target")) && env.hitEntity != null) sel = env.hitEntity.toString();
        else if (range > 0) sel = "@e[type=!minecraft:item,distance=.." + f(range) + ("true".equals(a.get("excludePlayer")) ? ",type=!minecraft:player" : "") + "]";
        else if (env.playerTarget != null) sel = env.playerTarget;
        else return;
        int dur = (int) Math.max(1, Math.round(num(a.get("duration"), 30)));
        int amp = (int) num(a.get("amplifier"), 0);
        boolean instant = id.startsWith("instant_");
        cmd(env, pos, "effect give " + sel + " minecraft:" + id + " " + (instant ? 1 : dur) + " " + amp + " true");
    }

    private static void cmd(Env env, Vec3 pos, String command) {
        MinecraftServer server = env.level.getServer();
        var src = server.createCommandSourceStack().withLevel(env.level).withPosition(pos).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, command);
    }

    // ---- utilitaires de conversion ------------------------------------------------------------

    private static String itemId(String id) {
        if (id.startsWith("lucky:")) {
            String n = id.substring(6);
            if (n.startsWith("astral_") || n.equals("lucky_block_astral")) return "astral:" + n;
            return null;                                // objets du mod Lucky Block d'origine : n'existent plus
        }
        if (id.startsWith("lootplusplus")) return null;
        return id.contains(":") ? id : "minecraft:" + id;
    }
    private static String blockId(String id) {
        if (id.startsWith("lootplusplus") || id.startsWith("lucky:")) return null;
        return id.contains(":") ? id : "minecraft:" + id;
    }
    private static String particleId(String id) { return id.contains(":") ? id : "minecraft:" + id; }
    private static String entityId(String id) {
        String s = id.replaceAll("([a-z])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
        return s.contains(":") ? s : "minecraft:" + s;
    }
    private static String randomSpawnEgg() {
        var keys = net.minecraft.core.registries.BuiltInRegistries.ITEM.keySet().stream()
            .filter(k -> k.getPath().endsWith("_spawn_egg")).toList();
        return keys.isEmpty() ? "minecraft:pig_spawn_egg" : keys.get(new Random().nextInt(keys.size())).toString().replace("minecraft:", "");
    }

    private static String xyz(Vec3 p) { return f(p.x) + " " + f(p.y) + " " + f(p.z); }
    private static String bxyz(Vec3 p) { BlockPos b = BlockPos.containing(p); return b.getX() + " " + b.getY() + " " + b.getZ(); }
    private static String f(double d) { return String.format(Locale.ROOT, "%.3f", d); }

    static double num(String s, double def) {
        if (s == null || s.isBlank()) return def;
        try { return Double.parseDouble(s.strip()); } catch (NumberFormatException e) { return def; }
    }
    /** "(1,2,3)", "1 2 3" ou "1,2,3". */
    static Vec3 vec(String s, Vec3 def) {
        if (s == null) return def;
        String[] p = s.replace("(", "").replace(")", "").strip().split("[,\\s]+");
        if (p.length < 3) return def;
        try { return new Vec3(Double.parseDouble(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2])); }
        catch (NumberFormatException e) { return def; }
    }
}
