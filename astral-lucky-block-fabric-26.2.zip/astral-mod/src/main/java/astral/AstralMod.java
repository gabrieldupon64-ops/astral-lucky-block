package astral;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;
import java.util.function.Function;

public class AstralMod implements ModInitializer {
    public static final String MOD_ID = "astral";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Block LUCKY_BLOCK;
    public static Item LUCKY_BLOCK_ITEM, LUCKY_SWORD, LUCKY_BOW, LUCKY_POTION;

    private static Identifier id(String path) { return Identifier.fromNamespaceAndPath(MOD_ID, path); }

    private static Item registerItem(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key).useItemDescriptionPrefix()));
    }

    @Override
    public void onInitialize() {
        // --- bloc + objet-bloc
        ResourceKey<Block> bkey = ResourceKey.create(Registries.BLOCK, id("lucky_block_astral"));
        LUCKY_BLOCK = Registry.register(BuiltInRegistries.BLOCK, bkey,
            new AstralLuckyBlock(BlockBehaviour.Properties.of().setId(bkey).strength(1.0F).sound(SoundType.STONE)));
        ResourceKey<Item> ikey = ResourceKey.create(Registries.ITEM, id("lucky_block_astral"));
        LUCKY_BLOCK_ITEM = Registry.register(BuiltInRegistries.ITEM, ikey,
            new BlockItem(LUCKY_BLOCK, new Item.Properties().setId(ikey).useBlockDescriptionPrefix()));

        // --- epee, arc, potion
        LUCKY_SWORD = registerItem("astral_lucky_sword", Item::new,
            new Item.Properties().sword(ToolMaterial.DIAMOND, 3.0F, -2.4F).rarity(Rarity.EPIC));
        LUCKY_BOW = registerItem("astral_lucky_bow", BowItem::new,
            new Item.Properties().durability(384).rarity(Rarity.EPIC));
        LUCKY_POTION = registerItem("astral_lucky_potion", LuckyPotionItem::new,
            new Item.Properties().stacksTo(16).rarity(Rarity.RARE));

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.BUILDING_BLOCKS).register(tab -> tab.accept(LUCKY_BLOCK_ITEM));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
            tab.accept(LUCKY_SWORD); tab.accept(LUCKY_BOW); tab.accept(LUCKY_POTION);
        });

        // --- donnees de l'addon
        DropRegistry.load();
        StructurePlacer.load();

        // --- epee : un coup a Config.swordChance de declencher un drop sur la cible
        AttackEntityCallback.EVENT.register((player, level, hand, target, hit) -> {
            if (level instanceof ServerLevel sl && player instanceof ServerPlayer sp && target instanceof LivingEntity le
                && sp.getItemInHand(hand).is(LUCKY_SWORD) && sl.getRandom().nextDouble() < Config.swordChance) {
                var env = DropRunner.env(sl, sp, le.position());
                env.hitEntity = le.getUUID();
                DropRunner.run(DropRegistry.pick(DropRegistry.Kind.SWORD, 0), env);
            }
            return InteractionResult.PASS;
        });

        // --- potions lancees et fleches de l'arc : on les suit jusqu'a l'impact
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity.getTags().contains(LuckyPotionItem.TAG)) {
                UUID owner = null;
                for (String t : entity.getTags())
                    if (t.startsWith(LuckyPotionItem.OWNER_TAG_PREFIX)) owner = UUID.fromString(t.substring(LuckyPotionItem.OWNER_TAG_PREFIX.length()));
                ProjectileTracker.track(entity, DropRegistry.Kind.POTION, owner);
            } else if (entity.getType().is(EntityTypeTags.ARROWS)) {
                // tireur = joueur proche qui tient l'arc Astral
                for (ServerPlayer p : ((ServerLevel) world).players()) {
                    if (p.distanceToSqr(entity) < 16 && (p.getMainHandItem().is(LUCKY_BOW) || p.getOffhandItem().is(LUCKY_BOW))) {
                        ProjectileTracker.track(entity, DropRegistry.Kind.BOW, p.getUUID());
                        break;
                    }
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> { Scheduler.tick(); ProjectileTracker.tick(server); });
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPING.register(s -> { Scheduler.clear(); ProjectileTracker.clear(); });

        LOGGER.info("Astral Lucky Block charge.");
    }
}
