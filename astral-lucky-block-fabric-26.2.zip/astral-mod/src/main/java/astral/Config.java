package astral;

/** Reglages (valeurs de properties.txt de l'addon + probabilites d'objets). */
public final class Config {
    public static boolean dropsInCreative = false;     // doDropsOnCreativeMode=false
    public static double swordChance = 0.25;           // probabilite qu'un coup d'epee declenche un drop
    public static double bowChance = 0.6;              // probabilite qu'une fleche declenche un drop a l'impact
    public static double potionChance = 1.0;
}
