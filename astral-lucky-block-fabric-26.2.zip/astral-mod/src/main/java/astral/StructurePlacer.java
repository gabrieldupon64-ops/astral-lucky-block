package astral;

import com.google.gson.*;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Map;

/** Pose les structures converties (data/astral/structures.json) dans le monde. */
public final class StructurePlacer {
    private record S(int w, int h, int l, String[] palette, int[][] blocks, int cx, int cy, int cz,
                     boolean overlay, String overlayStruct, boolean fixedRotation) {}
    private static final Map<String, S> STRUCTS = new HashMap<>();

    public static void load() {
        JsonObject root = JsonParser.parseString(DropRegistry.read("/data/astral/structures.json")).getAsJsonObject();
        for (var e : root.entrySet()) {
            JsonObject o = e.getValue().getAsJsonObject();
            JsonArray pal = o.getAsJsonArray("palette"), bl = o.getAsJsonArray("blocks");
            String[] palette = new String[pal.size()];
            for (int i = 0; i < palette.length; i++) palette[i] = pal.get(i).getAsString();
            int[][] blocks = new int[bl.size()][4];
            for (int i = 0; i < blocks.length; i++) for (int j = 0; j < 4; j++) blocks[i][j] = bl.get(i).getAsJsonArray().get(j).getAsInt();
            STRUCTS.put(e.getKey(), new S(o.get("w").getAsInt(), o.get("h").getAsInt(), o.get("l").getAsInt(), palette, blocks,
                o.get("centerX").getAsInt(), o.get("centerY").getAsInt(), o.get("centerZ").getAsInt(),
                o.get("overlay").getAsBoolean(), o.has("overlayStruct") && !o.get("overlayStruct").isJsonNull() ? o.get("overlayStruct").getAsString() : null,
                o.has("fixedRotation") && o.get("fixedRotation").getAsBoolean()));
        }
        AstralMod.LOGGER.info("Astral : {} structures chargees", STRUCTS.size());
    }

    public static boolean exists(String id) { return STRUCTS.containsKey(id); }

    /** @param rot quarts de tour (0..3) */
    public static void place(ServerLevel level, String id, BlockPos origin, int rot) {
        S s = STRUCTS.get(id);
        if (s == null) { AstralMod.LOGGER.warn("structure inconnue : {}", id); return; }
        if (s.fixedRotation) rot = 0;
        rot &= 3;
        Rotation rotation = Rotation.values()[rot];
        BlockState[] states = new BlockState[s.palette.length];
        var lookup = level.registryAccess().lookupOrThrow(Registries.BLOCK);
        for (int i = 0; i < states.length; i++) {
            try { states[i] = BlockStateParser.parseForBlock(lookup, s.palette[i], false).blockState().rotate(rotation); }
            catch (Exception ex) { AstralMod.LOGGER.warn("etat de bloc illisible : {}", s.palette[i]); states[i] = Blocks.STONE.defaultBlockState(); }
        }
        if (!s.overlay) {   // une structure normale remplace tout son volume (air compris)
            for (int y = 0; y < s.h; y++) for (int z = 0; z < s.l; z++) for (int x = 0; x < s.w; x++)
                level.setBlock(at(origin, x - s.cx, y - s.cy, z - s.cz, rot), Blocks.AIR.defaultBlockState(), 2);
        }
        for (int[] b : s.blocks)
            level.setBlock(at(origin, b[0] - s.cx, b[1] - s.cy, b[2] - s.cz, rot), states[b[3]], 2);
        if (s.overlayStruct != null) place(level, s.overlayStruct, origin, rot);
    }

    private static BlockPos at(BlockPos o, int dx, int dy, int dz, int rot) {
        return switch (rot) {
            case 1 -> o.offset(-dz, dy, dx);
            case 2 -> o.offset(-dx, dy, -dz);
            case 3 -> o.offset(dz, dy, -dx);
            default -> o.offset(dx, dy, dz);
        };
    }
}
