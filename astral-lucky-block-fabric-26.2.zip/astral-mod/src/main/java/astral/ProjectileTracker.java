package astral;

import astral.drop.Drop;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Suit les projectiles "Lucky" (potions lancees, fleches de l'arc) et declenche le drop quand ils se
 * terminent. Sans mixin : on regarde chaque tick si le projectile a disparu / s'est plante.
 */
public final class ProjectileTracker {
    private static final class T {
        final Entity e; final DropRegistry.Kind kind; final UUID owner; Vec3 last, motion; int age;
        T(Entity e, DropRegistry.Kind k, UUID o) { this.e = e; kind = k; owner = o; last = e.position(); motion = e.getDeltaMovement(); }
    }
    private static final List<T> LIST = new ArrayList<>();

    public static void track(Entity e, DropRegistry.Kind kind, UUID owner) { LIST.add(new T(e, kind, owner)); }

    public static void tick(net.minecraft.server.MinecraftServer server) {
        for (int i = 0; i < LIST.size(); i++) {
            T t = LIST.get(i);
            t.age++;
            boolean stuck = t.kind == DropRegistry.Kind.BOW && t.age > 3 && t.e.getDeltaMovement().lengthSqr() < 1.0E-4;
            if (!t.e.isRemoved() && !stuck && t.age < 1200) {
                t.last = t.e.position();
                if (t.e.getDeltaMovement().lengthSqr() > 1.0E-4) t.motion = t.e.getDeltaMovement();
                continue;
            }
            LIST.remove(i--);
            if (!(t.e.level() instanceof ServerLevel level)) continue;
            double chance = t.kind == DropRegistry.Kind.POTION ? Config.potionChance : Config.bowChance;
            if (level.getRandom().nextDouble() > chance) continue;
            ServerPlayer owner = server.getPlayerList().getPlayer(t.owner);
            Vec3 at = stuck ? t.e.position() : t.last;
            var env = DropRunner.env(level, owner, at);
            // entite touchee = entite vivante la plus proche de l'impact (hors tireur)
            LivingEntity hit = null; double best = 4.0;
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(2.0))) {
                if (owner != null && le == owner) continue;
                double d = le.distanceToSqr(at);
                if (d < best) { best = d; hit = le; }
            }
            if (hit != null) env.hitEntity = hit.getUUID();
            var c = env.ctx;
            c.bowX = at.x; c.bowY = at.y; c.bowZ = at.z;
            c.bowMx = t.motion.x; c.bowMy = t.motion.y; c.bowMz = t.motion.z;
            Drop d = DropRegistry.pick(t.kind, 0);
            DropRunner.run(d, env);
            if (t.kind == DropRegistry.Kind.BOW && !t.e.isRemoved()) t.e.discard();   // la fleche magique disparait apres son effet
        }
    }

    public static void clear() { LIST.clear(); }
}
