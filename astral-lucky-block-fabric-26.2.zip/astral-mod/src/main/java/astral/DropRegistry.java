package astral;

import astral.drop.Drop;
import astral.drop.DropParser;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Charge les fichiers de drops de l'addon (embarques dans le jar) et tire un drop pondere. */
public final class DropRegistry {
    public enum Kind { BLOCK("drops"), SWORD("sword_drops"), BOW("bow_drops"), POTION("potion_drops");
        final String file; Kind(String f) { file = f; } }

    private static final Map<Kind, List<Drop>> DROPS = new EnumMap<>(Kind.class);
    private static List<Drop> variants = List.of();

    public static void load() {
        for (Kind k : Kind.values()) {
            String txt = read("/data/astral/drops/" + k.file + ".txt");
            DROPS.put(k, DropParser.parse(txt));
            AstralMod.LOGGER.info("Astral : {} drops charges ({})", DROPS.get(k).size(), k);
        }
        // drops "sur mesure" des blocs places dans les structures (index = variant-1)
        try {
            var arr = com.google.gson.JsonParser.parseString(read("/data/astral/variant_drops.json")).getAsJsonArray();
            List<Drop> l = new ArrayList<>();
            arr.forEach(e -> l.add(DropParser.parseLine(e.getAsString().strip())));
            variants = l;
        } catch (RuntimeException e) { AstralMod.LOGGER.warn("variant_drops.json illisible", e); }
    }

    public static Drop variant(int i) { return (i >= 1 && i <= variants.size()) ? variants.get(i - 1) : null; }

    private static final Random RND = new Random();

    public static Drop pick(Kind kind, int luck) {
        Random rnd = RND;
        List<Drop> l = DROPS.getOrDefault(kind, List.of());
        double total = 0;
        for (Drop d : l) total += d.weight(luck);
        if (total <= 0) return null;
        double r = rnd.nextDouble() * total;
        for (Drop d : l) { r -= d.weight(luck); if (r <= 0) return d; }
        return l.get(l.size() - 1);
    }

    static String read(String path) {
        try (InputStream in = DropRegistry.class.getResourceAsStream(path)) {
            if (in == null) throw new IOException("ressource absente : " + path);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) { throw new RuntimeException(e); }
    }
}
