package astral;

import java.util.ArrayList;
import java.util.List;

/** Petit planificateur de taches differees (en ticks serveur), pour les "delay=" des drops. */
public final class Scheduler {
    private record Task(long at, Runnable r) {}
    private static final List<Task> TASKS = new ArrayList<>();
    private static long now = 0;

    public static void schedule(int ticks, Runnable r) {
        if (ticks <= 0) { r.run(); return; }
        TASKS.add(new Task(now + ticks, r));
    }

    public static void tick() {
        now++;
        for (int i = 0; i < TASKS.size(); i++) {
            Task t = TASKS.get(i);
            if (t.at <= now) { TASKS.remove(i--); try { t.r.run(); } catch (RuntimeException e) { AstralMod.LOGGER.warn("tache differee en erreur", e); } }
        }
    }
    public static void clear() { TASKS.clear(); }
}
