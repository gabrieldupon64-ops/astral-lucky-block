import gzip, struct, io
def read_nbt(path):
    data = gzip.open(path,'rb').read()
    buf = io.BytesIO(data)
    def rb(n): return buf.read(n)
    def rstr():
        l = struct.unpack('>H', rb(2))[0]; return rb(l).decode('utf8','replace')
    def payload(t):
        if t==1: return struct.unpack('>b',rb(1))[0]
        if t==2: return struct.unpack('>h',rb(2))[0]
        if t==3: return struct.unpack('>i',rb(4))[0]
        if t==4: return struct.unpack('>q',rb(8))[0]
        if t==5: return struct.unpack('>f',rb(4))[0]
        if t==6: return struct.unpack('>d',rb(8))[0]
        if t==7:
            n=struct.unpack('>i',rb(4))[0]; return rb(n)
        if t==8: return rstr()
        if t==9:
            it=struct.unpack('>b',rb(1))[0]; n=struct.unpack('>i',rb(4))[0]
            return [payload(it) for _ in range(n)]
        if t==10:
            d={}
            while True:
                tt=struct.unpack('>b',rb(1))[0]
                if tt==0: break
                k=rstr(); d[k]=payload(tt)
            return d
        if t==11:
            n=struct.unpack('>i',rb(4))[0]; return struct.unpack('>%di'%n, rb(4*n))
        raise ValueError(t)
    t=struct.unpack('>b',rb(1))[0]; rstr(); return payload(t)
