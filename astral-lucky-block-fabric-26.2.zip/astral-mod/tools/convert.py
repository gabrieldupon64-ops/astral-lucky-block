#!/usr/bin/env python3
"""Convertit l'addon Astral Lucky Block (Lucky Block 26.2) en ressources de mod Fabric."""
import sys, os, re, json, glob, shutil
sys.path.insert(0, os.path.dirname(__file__))
from nbtmini import read_nbt

SRC = sys.argv[1]; OUT = sys.argv[2]   # OUT = .../src/main/resources
COLORS = ["white","orange","magenta","light_blue","yellow","lime","pink","gray","light_gray","cyan","purple","blue","brown","green","red","black"]
FACE4 = {0:"east",1:"west",2:"south",3:"north"}          # stairs
CHEST = {2:"north",3:"south",4:"west",5:"east"}
TORCH = {1:"east",2:"west",3:"south",4:"north"}           # direction the torch points away from wall
PISTON = {0:"down",1:"up",2:"north",3:"south",4:"west",5:"east"}
DOORF = {0:"east",1:"south",2:"west",3:"north"}
GATEF = {0:"south",1:"west",2:"north",3:"east"}
STONE = {0:"stone",1:"granite",2:"polished_granite",3:"diorite",4:"polished_diorite",5:"andesite",6:"polished_andesite"}

def stairs(name, d):
    return f"minecraft:{name}[facing={FACE4[d&3]},half={'top' if d&4 else 'bottom'}]"
def slab(name, d):
    return f"minecraft:{name}[type={'top' if d&8 else 'bottom'}]"

def legacy(i, d):
    """(id, data) -> chaine blockstate moderne, ou None pour ignorer."""
    simple = {0:None,3:"dirt",9:"water",11:"lava",13:"gravel",20:"glass",22:"lapis_block",24:"sandstone",
      39:"brown_mushroom",40:"red_mushroom",41:"gold_block",42:"iron_block",49:"obsidian",51:"fire",
      57:"diamond_block",58:"crafting_table",80:"snow_block",82:"clay",87:"netherrack",88:"soul_sand",
      89:"glowstone",90:"nether_portal",101:"iron_bars",102:"glass_pane",110:"mycelium",112:"nether_bricks",
      113:"nether_brick_fence",119:"end_portal",121:"end_stone",123:"redstone_lamp",124:"redstone_lamp[lit=true]",
      140:"flower_pot",152:"redstone_block",165:"slime_block",166:"barrier",169:"sea_lantern",174:"packed_ice",
      191:"dark_oak_fence",85:"oak_fence",139:"cobblestone_wall",99:"brown_mushroom_block",100:"red_mushroom_block",
      70:"stone_pressure_plate",147:"light_weighted_pressure_plate",148:"heavy_weighted_pressure_plate",
      55:"redstone_wire",1:None}
    if i == 1: return f"minecraft:{STONE.get(d,'stone')}"
    if i in simple:
        s = simple[i]
        return None if s is None else "minecraft:"+s
    if i == 35: return f"minecraft:{COLORS[d&15]}_wool"
    if i == 95: return f"minecraft:{COLORS[d&15]}_stained_glass"
    if i == 160: return f"minecraft:{COLORS[d&15]}_stained_glass_pane"
    if i == 159: return f"minecraft:{COLORS[d&15]}_terracotta"
    if i == 171: return f"minecraft:{COLORS[d&15]}_carpet"
    if i == 43: return "minecraft:" + ["smooth_stone","sandstone","oak_planks","cobblestone","bricks","stone_bricks","nether_bricks","quartz_block"][d&7]
    if i == 44: return slab(["smooth_stone_slab","sandstone_slab","oak_slab","cobblestone_slab","brick_slab","stone_brick_slab","nether_brick_slab","quartz_slab"][d&7], d)
    if i == 53: return stairs("oak_stairs", d)
    if i == 109: return stairs("stone_brick_stairs", d)
    if i == 114: return stairs("nether_brick_stairs", d)
    if i == 128: return stairs("sandstone_stairs", d)
    if i == 156: return stairs("quartz_stairs", d)
    if i == 98: return "minecraft:" + ["stone_bricks","mossy_stone_bricks","cracked_stone_bricks","chiseled_stone_bricks"][d&3]
    if i == 97: return "minecraft:" + ["infested_stone","infested_cobblestone","infested_stone_bricks","infested_mossy_stone_bricks","infested_cracked_stone_bricks","infested_chiseled_stone_bricks"][min(d,5)]
    if i == 155: return "minecraft:" + ["quartz_block","chiseled_quartz_block","quartz_pillar","quartz_pillar"][d&3]
    if i == 50:
        return "minecraft:torch" if d==5 or d==0 else f"minecraft:wall_torch[facing={TORCH.get(d,'north')}]"
    if i in (54,): return f"minecraft:chest[facing={CHEST.get(d,'north')}]"
    if i == 61: return f"minecraft:furnace[facing={CHEST.get(d,'north')}]"
    if i == 23: return f"minecraft:dispenser[facing={PISTON.get(d&7,'north')}]"
    if i == 158: return f"minecraft:dropper[facing={PISTON.get(d&7,'north')}]"
    if i == 65: return f"minecraft:ladder[facing={CHEST.get(d,'north')}]"
    if i == 68: return f"minecraft:oak_wall_sign[facing={CHEST.get(d,'north')}]"
    if i == 63: return f"minecraft:oak_sign[rotation={d&15}]"
    if i in (29,33): return f"minecraft:{'sticky_piston' if i==29 else 'piston'}[facing={PISTON.get(d&7,'up')}]"
    if i == 93: return f"minecraft:repeater[facing={['north','east','south','west'][d&3]}]"
    if i == 69: return "minecraft:lever[face=wall,facing=north]"
    if i == 77: return "minecraft:stone_button[face=wall,facing=north]"
    if i == 143: return "minecraft:oak_button[face=wall,facing=north]"
    if i == 71: return f"minecraft:iron_door[facing={DOORF[d&3]},half={'upper' if d&8 else 'lower'}]"
    if i in (194,197): return f"minecraft:{'birch' if i==194 else 'dark_oak'}_door[facing={DOORF[d&3]},half={'upper' if d&8 else 'lower'}]"
    if i == 167: return f"minecraft:iron_trapdoor[facing={['north','south','west','east'][d&3]},half={'top' if d&8 else 'bottom'},open={'true' if d&4 else 'false'}]"
    if i in (183,184): return f"minecraft:{'spruce' if i==183 else 'birch'}_fence_gate[facing={GATEF[d&3]}]"
    if i == 145: return f"minecraft:anvil[facing={['south','west','north','east'][d&3]}]"
    if i == 26: return f"minecraft:red_bed[facing={['south','west','north','east'][d&3]},part={'head' if d&8 else 'foot'}]"
    if i == 120: return f"minecraft:end_portal_frame[facing={['south','west','north','east'][d&3]},eye={'true' if d&4 else 'false'}]"
    if i == 96: return None
    return "minecraft:stone"   # inconnu -> pierre (signale dans le rapport)

def read_properties(lines):
    p = {}
    for l in lines:
        if '=' in l:
            k,v = l.split('=',1); p[k.strip()] = v.strip()
    return p

report = {"unknown_ids": set(), "structures": 0}

def convert_schematic(path):
    d = read_nbt(path)
    W,H,L = d['Width'],d['Height'],d['Length']
    blocks, data = d['Blocks'], d['Data']
    palette, pidx, out = [], {}, []
    for y in range(H):
        for z in range(L):
            for x in range(W):
                k = (y*L+z)*W+x
                s = legacy(blocks[k] & 0xFF, data[k] & 0xFF)
                if s is None: continue
                if blocks[k] not in (1,3,9,11,13,20,22,24,39,40,41,42,43,44,49,50,51,53,54,55,57,58,61,63,65,68,69,70,71,77,80,82,85,87,88,89,90,93,95,97,98,99,100,101,102,109,110,112,113,114,119,120,121,123,124,128,139,140,143,145,147,148,152,155,156,158,159,160,165,166,167,169,171,174,183,184,191,194,197,23,26,29,33,35):
                    report["unknown_ids"].add(blocks[k])
                if s not in pidx: pidx[s] = len(palette); palette.append(s)
                out.append([x,y,z,pidx[s]])
    return {"w":W,"h":H,"l":L,"palette":palette,"blocks":out}

variants = []   # liste de lignes de drops custom
def luck_bucket(v):
    return max(-2,min(2,round(v/40)))

def convert_luckystruct(path):
    t = open(path,encoding='utf8',errors='replace').read().replace('\r','')
    t = re.sub(r'\\\n','',t)
    W=H=L=0; blocks=[]; palette=[]; pidx={}
    mode=None
    for line in t.split('\n'):
        s=line.strip()
        if s.startswith('>'): mode=s[1:]; continue
        if not s or s.startswith('/'): continue
        if mode=='properties' and '=' in s:
            k,v=s.split('=',1)
            if k=='width':W=int(v)
            if k=='height':H=int(v)
            if k=='length':L=int(v)
        elif mode=='blocks':
            m = re.match(r'^(\d+),(\d+),(\d+),([^,]+),(\d+)(?:,(.*))?$', s)
            if not m: continue
            x,y,z = int(m[1]),int(m[2]),int(m[3]); name=m[4]; nbt=m[6] or ''
            if name!='lucky:lucky_block_astral': continue
            lk = re.search(r'Luck=(-?\d+)', nbt)
            luck = luck_bucket(int(lk[1])) if lk else 0
            var = 0
            dm = re.search(r'Drops=\["(.*)"\]\)?\s*$', nbt, re.S)
            if dm:
                line = dm[1].replace('\\"','"')
                # sPos(a,b,c) -> position relative au bloc
                def rel(mm):
                    a,b,c = int(mm[1]),int(mm[2]),int(mm[3])
                    return f"#rel({a-x},{b-y},{c-z})"
                line = re.sub(r'\[#\]sPos\((-?\d+),(-?\d+),(-?\d+)\)', rel, line)
                line = line.replace('[#]drop(pos)','#bPos').replace('[#]drop(rotation)','0')
                if line not in variants: variants.append(line)
                var = variants.index(line)+1
            st = f"astral:lucky_block_astral[luck={luck+2},variant={var}]"
            if st not in pidx: pidx[st]=len(palette); palette.append(st)
            blocks.append([x,y,z,pidx[st]])
    return {"w":W,"h":H,"l":L,"palette":palette,"blocks":blocks,"fixedRotation":any('variant=0' not in p for p in palette)}

def main():
    res = OUT
    # --- structures
    sdir = os.path.join(res,'data/astral/astral_structures'); os.makedirs(sdir,exist_ok=True)
    files = {}
    for f in glob.glob(SRC+'/structures/**/*',recursive=True):
        if f.endswith('.schematic'): files[os.path.relpath(f,SRC+'/structures')] = convert_schematic(f)
        elif f.endswith('.luckystruct'): files[os.path.relpath(f,SRC+'/structures')] = convert_luckystruct(f)
    index = {}
    for l in open(SRC+'/structures.txt',encoding='utf8').read().replace('\r','').split('\n'):
        l=l.strip()
        if not l or l.startswith('/') or not l.startswith('ID='): continue
        kv = dict(p.split('=',1) for p in l.split(',') if '=' in p)
        if kv['file'] not in files: continue
        s = dict(files[kv['file']])
        s['centerX']=int(kv.get('centerX',0)); s['centerY']=int(kv.get('centerY',0)); s['centerZ']=int(kv.get('centerZ',0))
        s['overlay']=kv.get('blockMode')=='overlay'
        s['overlayStruct']=kv.get('overlayStruct')
        index[kv['ID']] = s
    # --- structures integrees du mod Lucky Block d'origine, absentes de l'addon : recreees ici (approximations)
    def build(w,h,l,cx,cy,cz,overlay,fn):
        pal,pidx,blocks=[],{},[]
        for y in range(h):
            for z in range(l):
                for x in range(w):
                    s=fn(x,y,z)
                    if s is None: continue
                    if s not in pidx: pidx[s]=len(pal); pal.append(s)
                    blocks.append([x,y,z,pidx[s]])
        return {"w":w,"h":h,"l":l,"palette":pal,"blocks":blocks,"fixedRotation":False,
                "centerX":cx,"centerY":cy,"centerZ":cz,"overlay":overlay,"overlayStruct":None}
    # fosse 3x3, 7 de profondeur, fond en pierre (le joueur tombe dedans)
    index['pit_trap'] = build(3,8,3,1,7,1,False, lambda x,y,z: "minecraft:stone" if y==0 else None)
    # puits de lave 3x3 (3 de profondeur) sous les pieds du joueur
    index['lava_trap'] = build(3,5,3,1,4,1,False, lambda x,y,z: "minecraft:lava" if y<=2 else None)
    # chateau gonflable : sol et murs en blocs de slime (se pose par-dessus le decor)
    index['bouncing_castle'] = build(7,4,7,3,0,3,True,
        lambda x,y,z: "minecraft:slime_block" if (y==0 or x in (0,6) or z in (0,6)) else None)
    json.dump(index, open(os.path.join(res,'data/astral/structures.json'),'w'), separators=(',',':'))
    json.dump(variants, open(os.path.join(res,'data/astral/variant_drops.json'),'w'), indent=1)
    os.rmdir(sdir)
    # --- drops
    ddir = os.path.join(res,'data/astral/drops'); os.makedirs(ddir,exist_ok=True)
    for n in ['drops','sword_drops','bow_drops','potion_drops','natural_gen','luck_crafting']:
        txt = open(f'{SRC}/{n}.txt',encoding='utf8').read().replace('\r','')
        open(f'{ddir}/{n}.txt','w',encoding='utf8').write(txt)
    # --- assets (namespace lucky -> astral)
    adir = os.path.join(res,'assets/astral')
    shutil.copytree(SRC+'/assets/astral', adir, dirs_exist_ok=True)
    for f in glob.glob(SRC+'/assets/lucky/**/*',recursive=True):
        if os.path.isdir(f): continue
        rel = os.path.relpath(f, SRC+'/assets/lucky')
        if rel.startswith('lang'): continue
        dst = os.path.join(adir, rel); os.makedirs(os.path.dirname(dst),exist_ok=True)
        if f.endswith('.json'):
            txt = open(f,encoding='utf8').read().replace('lucky:','astral:').replace('lucky_block_astral','lucky_block_astral')
            open(dst,'w',encoding='utf8').write(txt)
        else: shutil.copy(f,dst)
    # rewrite namespace refs in blockstate/models/items
    for f in glob.glob(adir+'/**/*.json',recursive=True):
        t=open(f,encoding='utf8').read()
        if 'lucky:' in t: open(f,'w',encoding='utf8').write(t.replace('lucky:','astral:'))
    print("structures:",len(index),"variants:",len(variants),"unknown ids:",sorted(report['unknown_ids']))
main()
