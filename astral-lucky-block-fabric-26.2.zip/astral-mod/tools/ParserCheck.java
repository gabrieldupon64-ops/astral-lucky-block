import astral.drop.*;
import java.nio.file.*;
import java.util.*;
public class ParserCheck {
  static int actions, groups; static Map<String,Integer> types = new TreeMap<>();
  static void walk(Node n, Ctx c, List<String> leftovers) {
    if (n.isGroup()) { groups++; for (Node k : n.children) walk(k, c, leftovers); return; }
    actions++; types.merge(n.attrs.get("type"),1,Integer::sum);
    for (var e : n.attrs.entrySet()) { String r; try { r = Fn.resolve(e.getValue(), c);} catch(RuntimeException ex){ System.out.println("ERR "+e.getKey()+" = "+e.getValue().substring(0,Math.min(300,e.getValue().length()))); return; } if (r.matches("(?s).*#(rand|p[A-Z]|b[A-Z]|circle|motion).*")) leftovers.add(e.getKey()+"="+r); }
  }
  public static void main(String[] a) throws Exception {
    Ctx c = new Ctx(); c.px=10.5;c.py=64;c.pz=-3.2;c.yaw=33;c.pitch=-10;c.bx=1;c.by=70;c.bz=2;
    for (String f : new String[]{"drops","sword_drops","bow_drops","potion_drops"}) {
      var drops = DropParser.parse(Files.readString(Path.of("/home/claude/astral-mod/src/main/resources/data/astral/drops/"+f+".txt")));
      List<String> left = new ArrayList<>();
      for (Drop d : drops) for (int i=0;i<20;i++) walk(d.root(), c, left);
      System.out.println(f+": "+drops.size()+" drops, leftovers="+left.size()+" "+(left.isEmpty()?"":left.get(0).substring(0,Math.min(200,left.get(0).length()))));
    }
    System.out.println(types);
    System.out.println(Fn.resolve("Motion:#motionFromDirection(#pYaw+#rand(-10,10),#pPitch+#rand(-10,10), 1.0) y=#bPosY+7 r=#rand(1,3) #rand(0.0,3.0)", c));
    System.out.println(Fn.resolve("#circleOffset(0.0,2.0) #randList(a,b,c) #minecraft:mineable/axe", c));
  }
}
