# Astral Lucky Block — mod Fabric (Minecraft 26.2)

Portage **autonome** de l'addon « Astral Lucky Block » : plus besoin du mod Lucky Block.

> ⚠️ **Non compilé et non testé en jeu.** J'ai pu tester la partie moteur de drops (parseur + fonctions `#rand`,
> `#randList`, `#circleOffset`…) : les 282 drops se lisent et se résolvent sans erreur. La partie Minecraft
> (blocs, items, structures, commandes) est écrite d'après la doc Fabric 26.x mais n'a pas pu être compilée ici.
> Attends-toi à corriger quelques noms de classes à la première compilation (voir plus bas).

## Obtenir le .jar sans rien installer
1. Crée un dépôt GitHub (gratuit) et envoie-y le contenu de ce dossier.
2. Onglet **Actions** → workflow **Build** → attends la fin (quelques minutes).
3. Télécharge l'artefact **astral-lucky-block-jar**, dézippe-le : le `.jar` est dedans.
4. Mets-le dans `.minecraft/mods/` avec **Fabric Loader** et **Fabric API** (26.2).

Si le build échoue, ouvre le log : les erreurs de compilation indiquent les signatures à corriger.

## Compiler
Prérequis : **JDK 25**, Gradle 9.3+.

```bash
gradle wrapper --gradle-version 9.3     # une seule fois (génère gradlew)
./gradlew build                          # jar dans build/libs/
./gradlew runClient                      # lancer le jeu de test
```
Vérifie les versions de `gradle.properties` (Loom, Fabric API, loader) sur https://fabricmc.net/develop/ :
j'ai mis celles trouvées pour 26.2, mais il en existe peut-être de plus récentes.

## Ce que contient le mod
| Élément | Fait |
|---|---|
| Bloc **Astral Lucky Block** (modèle + texture animée de l'addon) | ✅ au cassage, déclenche un drop pondéré |
| **Épée des Cieux** | ✅ chaque coup a 25 % de chances de déclencher un drop (`Config.java`) |
| **Star Shooter** (arc) | ✅ la flèche déclenche un drop à l'impact (60 %) |
| **Astral Lucky Potion** | ✅ clic droit = lancer ; drop à l'impact |
| ~282 drops (`drops`, `sword_drops`, `bow_drops`, `potion_drops`) | ✅ interprétés à l'exécution (`astral/drop/`) |
| ~66 structures (puits, balises, vaisseau, forts, temples, bloc géant…) | ✅ converties en JSON, posées par `StructurePlacer` |
| Recette | ✅ obsidienne + pépites d'or + étoile du Nether |
| Assets (objets, armures, textures) | ✅ namespace `lucky:` → `astral:` |

### Comment ça marche
Les fichiers de drops de l'addon sont embarqués tels quels. `DropParser` lit la syntaxe
(`group(...)`, `@luck`, `@chance`), `Fn` résout les `#fonctions`, et `DropRunner` traduit chaque action
en commandes vanilla (`summon`, `effect`, `particle`, `setblock`, `fill`, `playsound`…) ou en code Java
(explosion, knockback, structures). Les `delay=` passent par `Scheduler`.
La luck du bloc (-2…+2) est portée par l'état du bloc (`luck=0..4`), sans BlockEntity.

## Limites connues (honnêtes)
- **Luck** : pas de système de luck stockée sur l'objet ; le bloc obtenu en crafting a luck 0. Seuls les blocs
  des structures (forts/temples chanceux ou non) ont une luck fixée.
- **Poids des drops** : la formule `chance × (1 + luck_bloc × luck_drop × 0,35)` est une approximation de Lucky Block.
- **Structures** : conversion des anciens IDs numériques vers les blocs modernes par table (`tools/convert.py`) ;
  coffres, panneaux et entités des `.schematic` ne sont **pas** repris (coffres vides). Seul 1 bloc sur mesure
  (vaisseau, salle du boss) est converti ; ses éléments en syntaxe legacy (Skelatron, `lootplusplus`) sont ignorés.
- **Objets Loot++** (étoiles qui explosent, bottes à réaction, fée, rampe de lancement…) : ce sont des objets
  vanilla avec `item_model`/nom, comme dans le port d'origine — leurs comportements spéciaux n'existent pas.
- Les 71 drops de `a_verifier/` du port d'origine ne sont pas inclus.
- Pas de génération naturelle, ni de `luck_crafting.txt`.

## Points d'API 26.x à corriger si la compilation échoue
Ces appels sont les plus susceptibles d'avoir changé ; ils sont tous localisés :
- `AstralLuckyBlock.playerWillDestroy(...)` (signature)
- `LuckyPotionItem.use(...)` (type de retour `InteractionResult`)
- `AstralMod` : `CreativeModeTabEvents`, `ServerEntityEvents.ENTITY_LOAD`, `AttackEntityCallback`, `Item.Properties.sword(...)`
- `StructurePlacer` : `BlockStateParser.parseForBlock(...)`, `Rotation`
- `DropRunner` : `level.explode(...)`, `createCommandSourceStack()`, `performPrefixedCommand(...)`
Astuce : `javap -p` sur le jar Minecraft déobfusqué de Loom donne les signatures exactes.

## Régénérer les ressources depuis l'addon
```bash
python3 tools/convert.py <dossier_addon> src/main/resources
```
Vérifier le parseur de drops sans Minecraft : voir `tools/ParserCheck.java`.
