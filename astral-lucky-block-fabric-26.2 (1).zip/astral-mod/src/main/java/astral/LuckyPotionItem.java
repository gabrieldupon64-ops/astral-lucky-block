package astral;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/** Astral Lucky Potion : se lance comme une boule de neige et declenche un drop a l'impact. */
public class LuckyPotionItem extends Item {
    public LuckyPotionItem(Properties props) { super(props); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            Vec3 eye = player.getEyePosition();
            Vec3 m = player.getLookAngle().scale(1.2);
            String cmd = String.format(Locale.ROOT,
                "summon minecraft:snowball %.3f %.3f %.3f {Item:{id:\"astral:astral_lucky_potion\",count:1},Motion:[%.4fd,%.4fd,%.4fd]}",
                eye.x, eye.y - 0.1, eye.z, m.x, m.y, m.z);
            var server = sl.getServer();
            server.getCommands().performPrefixedCommand(
                server.createCommandSourceStack().withLevel(sl).withPosition(eye).withSuppressedOutput(), cmd);
            // la boule de neige vient d'apparaitre pres des yeux du joueur : on la suit jusqu'a l'impact
            Entity best = null; double bd = 4.0;
            for (Entity e : sl.getEntitiesOfClass(Entity.class, new AABB(eye, eye).inflate(1.5))) {
                if (!BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().equals("snowball")) continue;
                double d = e.distanceToSqr(eye);
                if (d < bd) { bd = d; best = e; }
            }
            if (best != null) ProjectileTracker.track(best, DropRegistry.Kind.POTION, player.getUUID());
            if (!player.isCreative()) stack.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
